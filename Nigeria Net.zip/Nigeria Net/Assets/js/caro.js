carousel

var nextbtn = document.querySelector('.next'),
    prevbtn = document.querySelector('.prev'),
    carousel = document.querySelector('.carousel'),
    list = document.querySelector('.list'),
    item = document.querySelectorAll('.item'),
    runningtime = document.querySelector('.timerunning')

let timerunning = 3000
let timeautonext = 7000

nextbtn.onclick = function () {
    showSlider('next')
}

prevbtn.onclick = function () {
    showSlider('prev')
}


let runtimeout
let runnextauto = setTimeout(() => {
    nextbtn.click()
}, timeautonext);


function resettimeanimation() {
    runningtime.style.animation = 'none'
    runningtime.offsetHeight
    runningtime.style.animation = 'runningtime 7s linear 1 forwards'
}


function showSlider(type) {
    let slideritemsdom = list.querySelectorAll('.carousel .list .item')
    if (type === 'next') {
        list.appendChild(slideritemsdom[0])
        carousel.classList.add('next')
    }else{
        list.prepend(slideritemsdom[slideritemsdom.length - 1])
        carousel.classList.add('prev')
    }

    clearTimeout(runtimeout)

    runtimeout = setTimeout(() => {
        carousel.classList.remove('next')
        carousel.classList.remove('prev')
    }, timerunning);


    clearTimeout(runnextauto)

    runnextauto = setTimeout(() => {
        nextbtn.click()
    }, timeautonext);

    resettimeanimation() //reset the running time of the animation
}


// start initial animation
resettimeanimation()
